package com.example.Eindopdracht_Backend;

public class Voorraad {
        private String Onderdeel;

        private int aantal;

        public Voorraad(String Onderdeel, int aantal) {
            this.Onderdeel = Onderdeel;
            this.aantal = aantal;
        }

        public String getOnderdeel() {
            return Onderdeel;
        }

        public int getAantal() {
            return aantal;
        }

        public class LeveringOnderdelen extends Voorraad{

            public LeveringOnderdelen(String Onderdeel, int aantal) {
                super(Onderdeel, aantal);
            }
        }
    }
