package com.example.Eindopdracht_Backend.validations.tasklists;

import ch.qos.logback.classic.Logger;
import com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppException;
import com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppErrors;
import com.example.Eindopdracht_Backend.models.requests.CreateTaskListRequest;
import com.example.Eindopdracht_Backend.validations.Validator;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Objects;

import static com.example.Eindopdracht_Backend.constants.Eindopdracht_BackendConstants.MAXIMUM_LENGTH_FOR_DESCRIPTION;
import static com.example.Eindopdracht_Backend.constants.Eindopdracht_BackendConstants.MAXIMUM_LENGTH_FOR_NAME;
import static com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppErrorMessages.*;

@Component
public class CreateTaskListsValidator implements Validator {

    private static final Logger log = (Logger) LoggerFactory.getLogger(CreateTaskListsValidator.class);

    @Override
    public <T> void validate(T object) throws Eindopdracht_BackendAppException {
        CreateTaskListRequest createTaskListRequest = (CreateTaskListRequest) object;
        validateMandatory(createTaskListRequest.getName());
        validateLengths(createTaskListRequest);
        log.info("Received request object for task list creation has been validated.");
    }

    private void validateLengths(CreateTaskListRequest createTaskListRequest) throws Eindopdracht_BackendAppException {
        if (createTaskListRequest.getName().length() > MAXIMUM_LENGTH_FOR_NAME) {
            throw new Eindopdracht_BackendAppException(NAME_MAX_LENGTH_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }

        if (Objects.nonNull(createTaskListRequest.getDescription()) && createTaskListRequest.getDescription().length() > MAXIMUM_LENGTH_FOR_DESCRIPTION) {
            throw new Eindopdracht_BackendAppException(DESCRIPTION_MAX_LENGTH_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }
    }

    private void validateMandatory(String name) throws Eindopdracht_BackendAppException {
        if (Objects.isNull(name) || name.isBlank() || name.isEmpty()) {
            throw new Eindopdracht_BackendAppException(NAME_MANDATORY_FIELD_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }
    }
}
