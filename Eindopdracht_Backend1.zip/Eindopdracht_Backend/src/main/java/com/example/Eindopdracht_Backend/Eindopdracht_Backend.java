package com.example.Eindopdracht_Backend;

import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.logging.Logger;

@SpringBootApplication
public class Eindopdracht_Backend {
    public static void main(String[] args) {
        SpringApplication.run(Eindopdracht_Backend.class, args);
    }

}
