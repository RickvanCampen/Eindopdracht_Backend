package com.example.Eindopdracht_Backend.models;

public class Auditable {
}
