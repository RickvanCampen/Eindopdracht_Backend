package com.example.Eindopdracht_Backend;

public class Afspraak {

        private String Datum;

        private String Fietsenmaker;

        private String Fiets;

        public Afspraak(String Datum, String Fietsenmakeer, String Fiets ) {
            this.Datum = Datum;
            this.Fietsenmaker = Fietsenmakeer;
            this.Fiets = Fiets;
        }

        public String getDatum() {
            return Datum;
        }

        public String getFietsenmaker() {
            return Fietsenmaker;
        }

        public String getFiets() {
            return Fiets;
        }

        public class Checkbeurt extends Afspraak{

            public Checkbeurt(String Datum, String Fietsenmakeer, String Fiets) {
                super(Datum, Fietsenmakeer, Fiets);
            }
        }
    }
