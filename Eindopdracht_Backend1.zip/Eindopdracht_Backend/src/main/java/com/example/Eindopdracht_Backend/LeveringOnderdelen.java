package com.example.Eindopdracht_Backend;

public class LeveringOnderdelen {
    private String Onderdeel;

    private int aantal;

    private String Datum;

    public LeveringOnderdelen(String Onderdeel, int aantal, String Datum) {
        this.Onderdeel = Onderdeel;
        this.aantal = aantal;
        this.Datum = Datum;
    }

    public String getOnderdeel() {
        return Onderdeel;
    }

    public int getAantal() {
        return aantal;
    }

    public String getDatum() {
        return Datum;
    }
    public class BestellingOnderdelen extends LeveringOnderdelen{

        public BestellingOnderdelen(String Onderdeel, int aantal, String Datum) {
            super(Onderdeel, aantal, Datum);
        }
    }
}

