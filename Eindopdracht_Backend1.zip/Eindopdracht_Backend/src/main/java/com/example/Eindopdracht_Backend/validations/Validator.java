package com.example.Eindopdracht_Backend.validations;

import com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppException;

public interface Validator {
    public <T> void validate(T object) throws Eindopdracht_BackendAppException;
}
