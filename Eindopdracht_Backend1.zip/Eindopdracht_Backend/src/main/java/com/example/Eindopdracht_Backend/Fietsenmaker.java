package com.example.Eindopdracht_Backend;

public class Fietsenmaker {

    private String naam;

    private Boolean beschikbaar;

    public Fietsenmaker(String naam, Boolean beschikbaar) {
        this.naam = naam;
        this.beschikbaar = beschikbaar;
    }

    public String getNaam() {
        return naam;
    }

    public Boolean getBeschikbaar() {
        return beschikbaar;
    }

    public class Fietsgarage extends Fietsenmaker {

        public Fietsgarage(String naam, Boolean beschikbaar) {
            super(naam, beschikbaar);
        }
    }
}

