package com.example.Eindopdracht_Backend.controllers;

import ch.qos.logback.classic.Logger;
import com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppException;
import com.example.Eindopdracht_Backend.models.responses.TaskListResponse;
import com.example.Eindopdracht_Backend.services.TaskListsService;
import com.example.Eindopdracht_Backend.models.requests.UpdateTaskListRequest;
import org.slf4j.LoggerFactory;
import com.example.Eindopdracht_Backend.models.requests.CreateTaskListRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import static com.example.Eindopdracht_Backend.constants.Eindopdracht_BackendConstants.*;

@RestController
public class TaskListsController {

    private static final Logger log = (Logger) LoggerFactory.getLogger(TaskListsController.class);

    @Autowired
    private TaskListsService taskListsService;

    @PostMapping(API + "/" + VERSION_1 + "/" + TASKLISTS_ENDPOINT)
    public TaskListResponse createTaskList(@RequestBody(required = true) CreateTaskListRequest createTaskListRequest) throws Eindopdracht_BackendAppException {
        try {
            log.info("Incoming request for task list creation.");
            return taskListsService.createTaskList(createTaskListRequest);
        } finally {
            log.info("Processing for task list creation request finished.");
        }
    }

    @PutMapping(API + "/" + VERSION_1 + "/" + TASKLISTS_ENDPOINT)
    public TaskListResponse updateTaskList(@RequestBody(required = true) UpdateTaskListRequest updateTaskListRequest) throws Eindopdracht_BackendAppException {
        try {
            log.info("Incoming request for task list update.");
            return taskListsService.updateTaskList(updateTaskListRequest);
        } finally {
            log.info("Processing for task list update request finished.");
        }
    }

    @GetMapping(API + "/" + VERSION_1 + "/" + TASKLISTS_ENDPOINT + "/" + "{task_list_uuid}")
    public TaskListResponse getTaskList(@PathVariable(name = "task_list_uuid", required = true) String taskListUuid) throws Eindopdracht_BackendAppException {
        try {
            log.info("Incoming request for task list fetch.");
            return taskListsService.getTaskList(taskListUuid);
        } finally {
            log.info("Processing for task list get request finished.");
        }
    }

    @DeleteMapping(API + "/" + VERSION_1 + "/" + TASKLISTS_ENDPOINT + "/" + "{task_list_uuid}")
    public void deleteTaskList(@PathVariable(name = "task_list_uuid", required = true) String taskListUuid) throws Eindopdracht_BackendAppException {
        try {
            log.info("Incoming request for task list delete.");
            taskListsService.deleteTaskList(taskListUuid);
        } finally {
            log.info("Processing for task list delete request finished.");
        }
    }
}
