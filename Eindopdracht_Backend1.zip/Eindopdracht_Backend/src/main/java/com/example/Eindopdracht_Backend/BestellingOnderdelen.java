package com.example.Eindopdracht_Backend;

public class BestellingOnderdelen {

    private String Onderdeel;

    private int aantal;

    private String Datum;

    public BestellingOnderdelen(String Onderdeel, int aantal, String Datum) {
        this.Onderdeel = Onderdeel;
        this.aantal = aantal;
        this.Datum = Datum;
    }

    public String getOnderdeel() {
        return Onderdeel;
    }

    public int getAantal() {
        return aantal;
    }

    public String getDatum() {
        return Datum;
    }

    public class Onderdelen extends BestellingOnderdelen {

        public Onderdelen(String Onderdeel, int aantal, String Datum) {
            super(Onderdeel, aantal, Datum);
        }
    }
}

