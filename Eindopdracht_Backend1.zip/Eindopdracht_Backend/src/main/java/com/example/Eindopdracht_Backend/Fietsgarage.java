package com.example.Eindopdracht_Backend;

public class Fietsgarage {

        private String naam;

        private String adres;

        private String telefoonnummer;

        private String Fiets[];

        private String Fietsenmaker[];

        private String Afspraak[];

        public void Garage(String naam, String adres, String telefoonnummer, String[] Fiets, String[] Fietsenmaker, String[] Afspraak) {
            this.naam = naam;
            this.adres = adres;
            this.telefoonnummer = telefoonnummer;
            this.Fiets = Fiets;
            this.Fietsenmaker = Fietsenmaker;
            this.Afspraak = Afspraak;

        }

        public String getNaam() {
            return naam;
        }

        public String getAdres() {
            return adres;

        }

        public String getTelefoonnummer() {
            return telefoonnummer;

        }

        public String[] getFiets() {
            return Fiets;
        }

        public String[] getFietsenmaker() {
            return Fietsenmaker;
        }

        public String[] getAfspraak() {
            return Afspraak;
        }
    }
