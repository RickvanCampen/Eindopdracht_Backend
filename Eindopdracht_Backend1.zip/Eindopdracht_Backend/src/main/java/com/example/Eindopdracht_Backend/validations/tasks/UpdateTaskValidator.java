package com.example.Eindopdracht_Backend.validations.tasks;

import ch.qos.logback.classic.Logger;
import com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppErrorMessages;
import com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppErrors;
import com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppException;
import com.example.Eindopdracht_Backend.validations.Validator;
import com.example.Eindopdracht_Backend.models.TaskStatus;
import com.example.Eindopdracht_Backend.models.requests.UpdateTaskRequest;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Objects;
import java.util.UUID;

import static com.example.Eindopdracht_Backend.constants.Eindopdracht_BackendConstants.MAXIMUM_LENGTH_FOR_DESCRIPTION;

@Component
public class UpdateTaskValidator implements Validator {

    private static final Logger log = (Logger) LoggerFactory.getLogger(UpdateTaskValidator.class);


    @Override
    public <T> void validate(T object) throws Eindopdracht_BackendAppException {
        UpdateTaskRequest updateTaskRequest = (UpdateTaskRequest) object;
        validateMandatory(updateTaskRequest);
        validateUuid(updateTaskRequest.getUuid());
        validateLengths(updateTaskRequest.getDescription());
        validateStatus(updateTaskRequest.getStatus());
        log.info("Received request object for task update has been validated.");
    }

    private void validateStatus(String status) throws Eindopdracht_BackendAppException {
        if (Objects.isNull(status)) {
            return;
        }
        TaskStatus taskStatus = Arrays.stream(TaskStatus.values())
                .filter(statusValue -> statusValue.name().equals(status))
                .findFirst()
                .orElse(null);
        if (Objects.isNull(taskStatus)) {
            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.TASK_STATUS_VALUE_INVALID_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }
    }

    private void validateLengths(String description) throws Eindopdracht_BackendAppException {
        if (Objects.nonNull(description) && description.length() > MAXIMUM_LENGTH_FOR_DESCRIPTION) {
            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.DESCRIPTION_MAX_LENGTH_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }
    }

    private void validateUuid(String uuid) throws Eindopdracht_BackendAppException {
        try {
            UUID isValidUUID = UUID.fromString(uuid);
        } catch (IllegalArgumentException  ex) {
            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.UUID_INVALID_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }
    }

    private void validateMandatory(UpdateTaskRequest updateTaskRequest) throws Eindopdracht_BackendAppException {
        if (Objects.isNull(updateTaskRequest.getUuid()) || updateTaskRequest.getUuid().isBlank() || updateTaskRequest.getUuid().isEmpty()) {
            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.UUID_MANDATORY_FIELD_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }

        if (Objects.isNull(updateTaskRequest.getDescription()) && Objects.isNull(updateTaskRequest.getStatus())) {

            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.MISSING_FIELD_FOR_UPDATE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }
    }
}
