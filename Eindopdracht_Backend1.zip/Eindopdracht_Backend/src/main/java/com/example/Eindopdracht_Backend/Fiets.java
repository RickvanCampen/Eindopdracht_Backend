package com.example.Eindopdracht_Backend;

public class Fiets {
        private String framenummer;

        private String merk;

        private String model;

        private int bouwjaar;

        private String Klant;

        private String Checkbeurt[];

        private String Reparatie[];

        public Fiets(String framenummer, String merk, String model, int bouwjaar, String Klant, String Checkbeurt[], String Reparatie[]) {
            this.framenummer = framenummer;
            this.merk = merk;
            this.model = model;
            this.bouwjaar = bouwjaar;
            this.Klant = Klant;
            this.Checkbeurt = Checkbeurt;
            this.Reparatie = Reparatie;
        }

        public String getFramenummer() {
            return framenummer;
        }

        public String getMerk() {
            return merk;
        }

        public String getModel() {
            return model;
        }

        public int getBouwjaar() {
            return bouwjaar;
        }

        public String getKlant() {
            return Klant;
        }

        public String[] getCheckbeurt() {
            return Checkbeurt;
        }

        public String[] getReparatie() {
            return Reparatie;
        }

        public class Klant extends Fiets {

            public Klant(String framenummer, String merk, String model, int bouwjaar, String Klant, String Checkbeurt[], String Reparatie[]) {
                super(framenummer, merk, model, bouwjaar, Klant, Checkbeurt, Reparatie);
            }
        }

        public class Fietsenmaker extends Fiets {

            public Fietsenmaker(String framenummer, String merk, String model, int bouwjaar, String Klant, String[] Checkbeurt, String[] Reparatie) {
                super(framenummer, merk, model, bouwjaar, Klant, Checkbeurt, Reparatie);
            }
        }
    }
