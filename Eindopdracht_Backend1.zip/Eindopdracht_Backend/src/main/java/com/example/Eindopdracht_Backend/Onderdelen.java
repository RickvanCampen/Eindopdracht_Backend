package com.example.Eindopdracht_Backend;

public class Onderdelen {
    private String naam;

    private String merk;

    private String type;

    private Double prijs;

    public Onderdelen(String naam, String merk, String type, Double prijs) {
        this.naam = naam;
        this.merk = merk;
        this.type = type;
        this.prijs = prijs;
    }

    public String getNaam() {
        return naam;
    }

    public String getMerk() {
        return merk;
    }

    public String getType() {
        return type;
    }

    public Double getPrijs() {
        return prijs;
    }

    public class Fietsgarage extends Onderdelen {

        public Fietsgarage(String naam, String merk, String type, Double prijs) {
            super(naam, merk, type, prijs);
        }
    }
}
