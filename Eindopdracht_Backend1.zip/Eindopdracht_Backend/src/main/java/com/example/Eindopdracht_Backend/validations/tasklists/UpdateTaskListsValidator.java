package com.example.Eindopdracht_Backend.validations.tasklists;

import ch.qos.logback.classic.Logger;
import com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppErrorMessages;
import com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppErrors;
import com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppException;
import com.example.Eindopdracht_Backend.validations.Validator;
import com.example.Eindopdracht_Backend.models.requests.UpdateTaskListRequest;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.UUID;

import static com.example.Eindopdracht_Backend.constants.Eindopdracht_BackendConstants.MAXIMUM_LENGTH_FOR_DESCRIPTION;

@Component
public class UpdateTaskListsValidator implements Validator {

    private static final Logger log = (Logger) LoggerFactory.getLogger(UpdateTaskListsValidator.class);

    @Override
    public <T> void validate(T object) throws Eindopdracht_BackendAppException {
        UpdateTaskListRequest updateTaskListRequest = (UpdateTaskListRequest) object;
        validateMandatory(updateTaskListRequest);
        validateUuid(updateTaskListRequest.getUuid());
        validateLengths(updateTaskListRequest.getDescription());
        log.info("Received request object for task list update has been validated.");
    }

    private void validateLengths(String description) throws Eindopdracht_BackendAppException {
        if (Objects.nonNull(description) && description.length() > MAXIMUM_LENGTH_FOR_DESCRIPTION) {
            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.DESCRIPTION_MAX_LENGTH_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }
    }

    private void validateUuid(String uuid) throws Eindopdracht_BackendAppException {
        try {
            UUID isValidUUID = UUID.fromString(uuid);
        } catch (IllegalArgumentException  ex) {
            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.UUID_INVALID_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }
    }

    private void validateMandatory(UpdateTaskListRequest updateTaskListRequest) throws Eindopdracht_BackendAppException {
        if (Objects.isNull(updateTaskListRequest.getUuid()) || updateTaskListRequest.getUuid().isBlank() || updateTaskListRequest.getUuid().isEmpty()) {
            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.UUID_MANDATORY_FIELD_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }

        if (Objects.isNull(updateTaskListRequest.getDescription())) {
            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.DESCRIPTION_MANDATORY_FIELD_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }
    }

}
