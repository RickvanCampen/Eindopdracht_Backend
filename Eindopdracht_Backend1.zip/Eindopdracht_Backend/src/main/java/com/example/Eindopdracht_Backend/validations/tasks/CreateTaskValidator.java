package com.example.Eindopdracht_Backend.validations.tasks;

import com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppErrorMessages;
import com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppErrors;
import com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppException;
import com.example.Eindopdracht_Backend.validations.Validator;
import com.example.Eindopdracht_Backend.models.requests.CreateTaskRequest;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.UUID;

import static com.example.Eindopdracht_Backend.constants.Eindopdracht_BackendConstants.MAXIMUM_LENGTH_FOR_DESCRIPTION;
import static com.example.Eindopdracht_Backend.constants.Eindopdracht_BackendConstants.MAXIMUM_LENGTH_FOR_NAME;

@Component
public class CreateTaskValidator implements Validator {


    @Override
    public <T> void validate(T object) throws Eindopdracht_BackendAppException {
        CreateTaskRequest createTaskRequest = (CreateTaskRequest) object;
        validateMandatory(createTaskRequest);
        validateLengths(createTaskRequest);
        validateUuid(createTaskRequest.getTaskListUuid());
    }

    private void validateUuid(String taskListUuid) throws Eindopdracht_BackendAppException {
        try {
            UUID isValidUUID = UUID.fromString(taskListUuid);
        } catch (IllegalArgumentException  ex) {
            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.UUID_INVALID_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }
    }

    private void validateLengths(CreateTaskRequest createTaskRequest) throws Eindopdracht_BackendAppException {
        if (createTaskRequest.getName().length() > MAXIMUM_LENGTH_FOR_NAME) {
            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.NAME_MAX_LENGTH_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }

        if (Objects.nonNull(createTaskRequest.getDescription()) && createTaskRequest.getDescription().length() > MAXIMUM_LENGTH_FOR_DESCRIPTION) {
            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.DESCRIPTION_MAX_LENGTH_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }
    }

    private void validateMandatory(CreateTaskRequest createTaskRequest) throws Eindopdracht_BackendAppException {
        if (Objects.isNull(createTaskRequest.getName()) || createTaskRequest.getName().isBlank() || createTaskRequest.getName().isEmpty()) {
            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.NAME_MANDATORY_FIELD_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }

        if (Objects.isNull(createTaskRequest.getDescription())) {
            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.DESCRIPTION_MANDATORY_FIELD_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }

        if (Objects.isNull(createTaskRequest.getTaskListUuid()) || createTaskRequest.getTaskListUuid().isBlank() || createTaskRequest.getTaskListUuid().isEmpty()) {
            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.UUID_MANDATORY_FIELD_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }
    }
}
