package com.example.Eindopdracht_Backend;

public class Klant {

    private String naam;

    private String adres;

    private String emailadres;

    private String telefoonnummer;

    private String Fiets[];

    public Klant(String naam, String adres, String emailadres, String telefoonnummer, String Fiets[]) {
        this.naam = naam;
        this.adres = adres;
        this.emailadres = emailadres;
        this.telefoonnummer = telefoonnummer;
        this.Fiets = Fiets;
    }

    public String getNaam() {
        return naam;
    }

    public String getAdres() {
        return adres;
    }

    public String getEmailadres() {
        return emailadres;
    }

    public String getTelefoonnummer() {
        return telefoonnummer;
    }

    public String[] getFiets() {
        return Fiets;
    }

    public class Fietsgarage extends Klant {

        public Fietsgarage(String naam, String adres, String emailadres, String telefoonnummer, String Fiets[]) {
            super(naam, adres, emailadres, telefoonnummer, Fiets);
        }
    }
}
