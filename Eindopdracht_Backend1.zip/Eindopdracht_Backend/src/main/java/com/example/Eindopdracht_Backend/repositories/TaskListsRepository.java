package com.example.Eindopdracht_Backend.repositories;

import com.example.Eindopdracht_Backend.models.TaskLists;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface TaskListsRepository extends JpaRepository<TaskLists, UUID> {

    Optional<TaskLists> findByName(String name);
}
