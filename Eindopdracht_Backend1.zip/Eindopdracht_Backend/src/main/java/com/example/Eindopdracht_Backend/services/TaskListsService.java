package com.example.Eindopdracht_Backend.services;

import ch.qos.logback.classic.Logger;
import com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppErrorMessages;
import com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppErrors;
import com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppException;
import com.example.Eindopdracht_Backend.repositories.TaskListsRepository;
import com.example.Eindopdracht_Backend.validations.tasklists.CreateTaskListsValidator;
import com.example.Eindopdracht_Backend.validations.tasklists.GetTaskListsValidator;
import com.example.Eindopdracht_Backend.validations.tasklists.UpdateTaskListsValidator;
import com.example.Eindopdracht_Backend.models.TaskLists;
import com.example.Eindopdracht_Backend.models.requests.CreateTaskListRequest;
import com.example.Eindopdracht_Backend.models.requests.UpdateTaskListRequest;
import com.example.Eindopdracht_Backend.models.responses.TaskListResponse;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Optional;
import java.util.UUID;

@Service
public class TaskListsService {

    private static final Logger log = (Logger) LoggerFactory.getLogger(TaskListsService.class);

    @Autowired
    private CreateTaskListsValidator createTaskListsValidator;

    @Autowired
    private UpdateTaskListsValidator updateTaskListsValidator;

    @Autowired
    private GetTaskListsValidator getTaskListsValidator;

    @Autowired
    private TaskListsRepository taskListsRepository;

    public TaskListResponse createTaskList(CreateTaskListRequest createTaskListRequest) throws Eindopdracht_BackendAppException {
        log.info("Processing request for task list creation.");
        createTaskListsValidator.validate(createTaskListRequest);
        TaskLists taskLists = createTaskListInDB(createTaskListRequest);
        return TaskListResponse.builder()
                .uuid(taskLists.getUuid())
                .name(taskLists.getName())
                .description(taskLists.getDescription())
                .build();
    }

    private TaskLists createTaskListInDB(CreateTaskListRequest createTaskListRequest) throws Eindopdracht_BackendAppException {
        checkExistence(createTaskListRequest.getName());
        TaskLists taskList = TaskLists.builder()
                .name(createTaskListRequest.getName())
                .description(createTaskListRequest.getDescription())
                .uuid(UUID.randomUUID())
                .createdAt(new Date())
                .updatedAt(new Date())
                .build();
        TaskLists taskLists = null;
        try {
            taskLists = taskListsRepository.save(taskList);
            log.info("Task list has been created. Returning the newly created object.");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return taskLists;
    }

    private void checkExistence(String name) throws Eindopdracht_BackendAppException {
        Optional<TaskLists> taskListsOptional = taskListsRepository.findByName(name);
        if (taskListsOptional.isPresent() && !taskListsOptional.get().getIsDeleted()) {
            log.info("Task list with name : " + name + " already exist. Sending error response.");
            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.DUPLICATE_ENTRY_FOUND + name, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_004);
        }
    }

    public TaskListResponse updateTaskList(UpdateTaskListRequest updateTaskListRequest) throws Eindopdracht_BackendAppException {
        log.info("Processing request for task list update.");
        updateTaskListsValidator.validate(updateTaskListRequest);
        TaskLists taskLists = updateTaskListInDB(updateTaskListRequest);
        return TaskListResponse.builder()
                .uuid(taskLists.getUuid())
                .name(taskLists.getName())
                .description(taskLists.getDescription())
                .build();
    }

    private TaskLists updateTaskListInDB(UpdateTaskListRequest updateTaskListRequest) throws Eindopdracht_BackendAppException {
        TaskLists oldTaskList = checkExistence(UUID.fromString(updateTaskListRequest.getUuid()));
        TaskLists newTaskList = TaskLists.builder()
                .name(oldTaskList.getName())
                .description(updateTaskListRequest.getDescription())
                .uuid(oldTaskList.getUuid())
                .createdAt(oldTaskList.getCreatedAt())
                .updatedAt(new Date())
                .isDeleted(oldTaskList.getIsDeleted())
                .build();
        try {
            newTaskList = taskListsRepository.save(newTaskList);
            log.info("Task list has been updated. Returning the updated object.");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return newTaskList;
    }

    private TaskLists checkExistence(UUID uuid) throws Eindopdracht_BackendAppException {
        Optional<TaskLists> taskListsOptional = taskListsRepository.findById(uuid);
        if (taskListsOptional.isEmpty() || taskListsOptional.get().getIsDeleted()) {
            log.info("Task list with uuid : " + uuid + " either does not exist or deleted. Sending error response.");
            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.TASK_LIST_NOT_FOUND_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_002);
        }
        return taskListsOptional.get();
    }

    public TaskListResponse getTaskList(String taskListUuid) throws Eindopdracht_BackendAppException {
        log.info("Processing request for task list fetch.");
        getTaskListsValidator.validate(taskListUuid);
        TaskLists taskLists = fetchTaskList(taskListUuid);
        return TaskListResponse.builder()
                .uuid(taskLists.getUuid())
                .name(taskLists.getName())
                .description(taskLists.getDescription())
                .build();
    }

    private TaskLists fetchTaskList(String taskListUuid) throws Eindopdracht_BackendAppException {
        Optional<TaskLists> taskListsOptional = Optional.empty();
        try {
            taskListsOptional = taskListsRepository.findById(UUID.fromString(taskListUuid));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        if (taskListsOptional.isEmpty() || taskListsOptional.get().getIsDeleted()) {
            log.info("Task list with uuid : " + taskListUuid + " either does not exist or deleted. Sending error response.");
            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.TASK_LIST_NOT_FOUND_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_002);
        }
        return taskListsOptional.get();
    }

    public void deleteTaskList(String taskListUuid) throws Eindopdracht_BackendAppException {
        log.info("Processing request for task list delete.");
        getTaskListsValidator.validate(taskListUuid);
        TaskLists taskLists = checkExistence(UUID.fromString(taskListUuid));
        deleteTaskListInDB(taskLists);
    }

    private void deleteTaskListInDB(TaskLists taskLists) {
        try {
            taskLists.setIsDeleted(true);
            taskLists.setUpdatedAt(new Date());
            taskListsRepository.save(taskLists);
            log.info("Task list has been deleted.");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
