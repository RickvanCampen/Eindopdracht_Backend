package com.example.Eindopdracht_Backend.exceptionhandle;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class Eindopdracht_BackendAppException extends Exception {

    private Eindopdracht_BackendAppErrors errorCode;
    private String message;

    public Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrors errorCode) {
        this.errorCode = errorCode;
    }

    public Eindopdracht_BackendAppException(String message, Eindopdracht_BackendAppErrors errorCode) {
        this.errorCode = errorCode;
        this.message = message;
    }

}
