package com.example.Eindopdracht_Backend;

public class Checkbeurt {
        private String Datum;

        private String Fietsenmaker;

        private String beschrijving;

        public Checkbeurt(String Datum, String Fietsenmakeer, String beschrijving ) {
            this.Datum = Datum;
            this.Fietsenmaker = Fietsenmakeer;
            this.beschrijving = beschrijving;
        }

        public String getDatum() {
            return Datum;
        }

        public String getFietsenmaker() {
            return Fietsenmaker;
        }

        public String getBeschrijving() {
            return beschrijving;
        }

        public class Fietsenmaker extends Checkbeurt{

            public Fietsenmaker(String Datum, String Fietsenmaker, String beschrijving ) {
                super(Datum, Fietsenmaker, beschrijving);
            }
        }
    }
