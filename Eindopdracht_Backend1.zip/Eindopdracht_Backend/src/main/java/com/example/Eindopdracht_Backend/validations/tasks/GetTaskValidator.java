package com.example.Eindopdracht_Backend.validations.tasks;

import com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppErrorMessages;
import com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppErrors;
import com.example.Eindopdracht_Backend.exceptionhandle.Eindopdracht_BackendAppException;
import com.example.Eindopdracht_Backend.validations.Validator;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.UUID;

@Component
public class GetTaskValidator implements Validator {

    @Override
    public <T> void validate(T object) throws Eindopdracht_BackendAppException {
        String taskUuid = (String) object;
        validateMandatory(taskUuid);
        validateUuid(taskUuid);
    }

    private void validateMandatory(String taskUuid) throws Eindopdracht_BackendAppException {
        if (Objects.isNull(taskUuid) || taskUuid.isBlank() || taskUuid.isEmpty()) {
            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.UUID_MANDATORY_FIELD_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }
    }

    private void validateUuid(String uuid) throws Eindopdracht_BackendAppException {
        try {
            UUID isValidUUID = UUID.fromString(uuid);
        } catch (IllegalArgumentException  ex) {
            throw new Eindopdracht_BackendAppException(Eindopdracht_BackendAppErrorMessages.UUID_INVALID_MESSAGE, Eindopdracht_BackendAppErrors.TO_DO_APP_ERROR_001);
        }
    }
}
