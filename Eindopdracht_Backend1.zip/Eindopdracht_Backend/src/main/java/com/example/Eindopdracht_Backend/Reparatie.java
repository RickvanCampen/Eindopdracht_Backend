package com.example.Eindopdracht_Backend;

public class Reparatie {
        private String Fiets;

        private String Datum;

        private String omschrijving;

        private Double kosten;

        public Reparatie(String Fiets, String Datum, String omschrijving, Double kosten) {
            this.Fiets = Fiets;
            this.Datum = Datum;
            this.omschrijving = omschrijving;
            this.kosten = kosten;
        }

        public String getFiets() {
            return Fiets;
        }

        public String getDatum() {
            return Datum;
        }

        public String getOmschrijving() {
            return omschrijving;
        }

        public Double getKosten() {
            return kosten;
        }

        public class Fiets extends Reparatie {

            public Fiets(String Fiets, String Datum, String omschrijving, Double kosten) {
                super(Fiets, Datum, omschrijving, kosten);
            }
        }
    }
