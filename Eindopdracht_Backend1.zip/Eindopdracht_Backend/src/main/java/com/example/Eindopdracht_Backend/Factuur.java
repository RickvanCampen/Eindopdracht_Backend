package com.example.Eindopdracht_Backend;

public class Factuur {
        private String Klant;

        private String Reparaties[];

        private String Datum;

        private Double totaalbedrag;

        private int factuurnummer;

        public Factuur(String Klant, String Reparaties[], String Datum, Double totaalbedrag, int factuurnummer) {
            this.Klant  = Klant;
            this.Reparaties = Reparaties;
            this.Datum = Datum;
            this.totaalbedrag = totaalbedrag;
            this.factuurnummer = factuurnummer;
        }

        public String getKlant() {
            return Klant;
        }

        public String[] getReparaties() {
            return Reparaties;
        }

        public String getDatum() {
            return Datum;
        }

        public Double getTotaalbedrag() {
            return totaalbedrag;
        }

        public int getFactuurnummer() {
            return factuurnummer;
        }
        public class Medewerker extends Factuur{

            public Medewerker(String Klant, String Reparaties[], String Datum, Double totaalbedrag, int factuurnummer) {
                super(Klant, Reparaties, Datum, totaalbedrag, factuurnummer);
            }
        }
    }