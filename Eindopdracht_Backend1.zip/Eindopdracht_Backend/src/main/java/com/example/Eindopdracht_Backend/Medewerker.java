package com.example.Eindopdracht_Backend;

public class Medewerker {

    private String naam;

    private String telefoonnummer;

    private String functie;

    private Double salaris;

    private String werkzaamheden;

    public Medewerker(String naam, String telefoonnummer, String functie, Double salaris, String werkzaamheden) {
        this.naam = naam;
        this.telefoonnummer = telefoonnummer;
        this.functie = functie;
        this.salaris = salaris;
        this.werkzaamheden = werkzaamheden;
    }

    public String getNaam() {
        return naam;
    }

    public String getTelefoonnummer() {
        return telefoonnummer;
    }

    public String getFunctie() {
        return functie;
    }

    public Double getSalaris() {
        return salaris;
    }

    public String getWerkzaamheden() {
        return werkzaamheden;
    }

    public class Fietsgarage extends Medewerker {

        public Fietsgarage(String naam, String telefoonnummer, String functie, Double salaris, String werkzaamheden) {
            super(naam, telefoonnummer, functie, salaris, werkzaamheden);
        }
    }
}
