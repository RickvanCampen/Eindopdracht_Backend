package com.example.Eindopdracht_Backend;

import com.example.Eindopdracht_Backend.models.TaskStatus;

import javax.swing.*;
import java.util.Collection;

public class Fietsgarage {

        private String naam;

        private String adres;

        private String telefoonnummer;

        private String Fiets[];

        private String Fietsenmaker[];

        private String Afspraak[];

        public void Garage(String naam, String adres, String telefoonnummer, String[] Fiets, String[] Fietsenmaker, String[] Afspraak) {
            this.naam = naam;
            this.adres = adres;
            this.telefoonnummer = telefoonnummer;
            this.Fiets = Fiets;
            this.Fietsenmaker = Fietsenmaker;
            this.Afspraak = Afspraak;

        }

        public String getNaam() {
            return naam;
        }

        public String getAdres() {
            return adres;

        }

        public String getTelefoonnummer() {
            return telefoonnummer;

        }

        public String[] getFiets() {
            return Fiets;
        }

        public String[] getFietsenmaker() {
            return Fietsenmaker;
        }

        public String[] getAfspraak() {
            return Afspraak;
        }

    public void addFiets(com.example.Eindopdracht_Backend.Fiets bike1) {
    }

    public void removeFiets(com.example.Eindopdracht_Backend.Fiets fiets) {
    }

    public Object getFietsCount() {
    return getFietsCount();}

    public Collection<Object> getAllFietsen() {
    return getAllFietsen();}

    public JColorChooser getFietsById(String s) {
    return getFietsById();}

    private JColorChooser getFietsById() {
    return getFietsById();}


}
