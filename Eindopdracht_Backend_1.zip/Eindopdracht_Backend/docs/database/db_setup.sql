---
--- The SQL commands in this file are only to create basic database & user.
--- Please customize as per your requirement or study practice.
---

create database Eindopdracht_Backend;

create user 'Eindopdracht_Backend-user'@'%' identified by 'PASSWORD_OF_YOUR_CHOICE';
grant all privileges on 'Eindopdracht_Backend-user'@'%''@''.* ''TO Eindopdracht_Backend-user;

FLUSH PRIVILEGES;

